package com.zahrati.drawing

import android.Manifest
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import android.graphics.BitmapFactory
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private val Ink = Color(0xFF21172D)
private val Violet = Color(0xFF8C63C7)
private val Lilac = Color(0xFFF1EAF9)
private val Paper = Color(0xFFFFFCFF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(33, 23, 45)
        window.navigationBarColor = android.graphics.Color.rgb(33, 23, 45)
        setContent { ZahratiApp() }
    }
}

@Composable
private fun ZahratiApp() {
    var screen by remember { mutableStateOf("home") }
    var selectedImage by remember { mutableStateOf<Uri?>(null) }
    var opacity by remember { mutableFloatStateOf(0.45f) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) { selectedImage = uri; screen = "trace" }
    }
    MaterialTheme(colorScheme = lightColorScheme(primary = Violet, background = Paper, surface = Paper)) {
        when (screen) {
            "trace" -> TraceScreen(
                imageUri = selectedImage,
                opacity = opacity,
                onOpacity = { opacity = it },
                onBack = { screen = "home" },
                onPick = { picker.launch("image/*") }
            )
            "library" -> LibraryScreen(
                onBack = { screen = "home" },
                onChoose = { selectedImage = it; screen = "trace" },
                onImport = { picker.launch("image/*") }
            )
            else -> HomeScreen(
                onTrace = { picker.launch("image/*") },
                onCamera = { selectedImage = null; screen = "trace" },
                onLibrary = { screen = "library" }
            )
        }
    }
}

@Composable
private fun HomeScreen(onTrace: () -> Unit, onCamera: () -> Unit, onLibrary: () -> Unit) {
    Column(
        Modifier.fillMaxSize().background(Paper).padding(horizontal = 20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(24.dp))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(46.dp).clip(RoundedCornerShape(16.dp)).background(Lilac), contentAlignment = Alignment.Center) {
                Icon(Icons.Default.Brush, null, tint = Violet, modifier = Modifier.size(28.dp))
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text("زهرتي", fontSize = 27.sp, fontWeight = FontWeight.Bold, color = Ink)
                Text("خلّي خيالك يصير رسمة", fontSize = 13.sp, color = Color.Gray)
            }
            Icon(Icons.Default.AutoAwesome, null, tint = Violet, modifier = Modifier.size(25.dp))
        }
        Spacer(Modifier.height(24.dp))
        Box(Modifier.fillMaxWidth().height(190.dp).clip(RoundedCornerShape(26.dp)).background(Ink).padding(20.dp)) {
            Column(Modifier.align(Alignment.CenterStart).fillMaxWidth(0.72f)) {
                Text("كل رسمة\nتبدأ بخطوة", fontSize = 27.sp, lineHeight = 34.sp, fontWeight = FontWeight.Bold, color = Color.White)
                Spacer(Modifier.height(8.dp))
                Text("اختَر صورة، ثبّت هاتفك، وابدأ التتبّع على الورق", fontSize = 13.sp, color = Color(0xFFD8C9E9))
            }
            Icon(Icons.Default.Draw, null, tint = Color(0xFFB99AE7), modifier = Modifier.align(Alignment.BottomEnd).size(82.dp))
        }
        Spacer(Modifier.height(22.dp))
        Text("ابدأ الرسم", modifier = Modifier.fillMaxWidth(), color = Ink, fontSize = 19.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        ActionTile(Icons.Default.AddPhotoAlternate, "ارسم من صورة", "اختر صورة من جهازك وابدأ التتبّع", onTrace)
        Spacer(Modifier.height(10.dp))
        ActionTile(Icons.Default.CameraAlt, "الرسم بالكاميرا", "اعرض الصورة فوق الورقة باستخدام الكاميرا", onCamera)
        Spacer(Modifier.height(10.dp))
        ActionTile(Icons.Default.Collections, "مكتبة الرسومات", "اكتشف أفكاراً جاهزة للتدريب", onLibrary)
        Spacer(Modifier.weight(1f))
        Text("الحقوق © زهرتي", fontSize = 11.sp, color = Color(0xFF9A8EA8), modifier = Modifier.padding(bottom = 14.dp))
    }
}

@Composable
private fun ActionTile(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, subtitle: String, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Lilac)
            .clickable(onClick = onClick).padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(48.dp).clip(RoundedCornerShape(15.dp)).background(Color.White), contentAlignment = Alignment.Center) {
            Icon(icon, null, tint = Violet, modifier = Modifier.size(25.dp))
        }
        Spacer(Modifier.width(13.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = Ink, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Spacer(Modifier.height(3.dp))
            Text(subtitle, color = Color(0xFF756A80), fontSize = 12.sp)
        }
        Icon(Icons.Default.ChevronLeft, null, tint = Violet)
    }
}

@Composable
private fun LibraryScreen(onBack: () -> Unit, onChoose: (Uri) -> Unit, onImport: () -> Unit) {
    Column(Modifier.fillMaxSize().background(Paper).padding(20.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null, tint = Ink) }
            Text("مكتبة الرسومات", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Ink)
        }
        Spacer(Modifier.height(12.dp))
        Text("اختَر صورة من جهازك لتبدأ التتبّع. يمكنك إضافة أي رسمة تريدها.", color = Color.Gray, fontSize = 14.sp)
        Spacer(Modifier.height(20.dp))
        val categories = listOf(
            Triple(Icons.Default.LocalFlorist, "ورود وطبيعة", "رسومات الزهور والأشجار"),
            Triple(Icons.Default.Pets, "حيوانات", "تدرّب على الأشكال والملامح"),
            Triple(Icons.Default.DirectionsCar, "سيارات", "خطوط وأشكال هندسية"),
            Triple(Icons.Default.Face, "وجوه وشخصيات", "ارسم الوجوه والتفاصيل"),
            Triple(Icons.Default.Home, "بيوت ومبانٍ", "مناظر وبيوت بسيطة"),
            Triple(Icons.Default.Brush, "رسومات متنوعة", "أفكار إضافية للرسم")
        )
        LazyVerticalGrid(columns = GridCells.Fixed(2), verticalArrangement = Arrangement.spacedBy(12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            items(categories) { item ->
                Column(
                    Modifier.fillMaxWidth().height(135.dp).clip(RoundedCornerShape(20.dp))
                        .background(Lilac).clickable(onClick = onImport).padding(14.dp),
                    verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(item.first, null, tint = Violet, modifier = Modifier.size(35.dp))
                    Spacer(Modifier.height(9.dp))
                    Text(item.second, color = Ink, fontWeight = FontWeight.Bold)
                    Text(item.third, color = Color.Gray, fontSize = 10.sp)
                }
            }
        }
        Spacer(Modifier.height(14.dp))
        Button(onClick = onImport, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
            Icon(Icons.Default.AddPhotoAlternate, null)
            Spacer(Modifier.width(8.dp))
            Text("اختيار صورة من الهاتف")
        }
        Spacer(Modifier.height(8.dp))
        Text("الحقوق © زهرتي", modifier = Modifier.align(Alignment.CenterHorizontally), color = Color.Gray, fontSize = 11.sp)
    }
}

@Composable
private fun TraceScreen(imageUri: Uri?, opacity: Float, onOpacity: (Float) -> Unit, onBack: () -> Unit, onPick: () -> Unit) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    var hasCamera by remember { mutableStateOf(ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) }
    var flashOn by remember { mutableStateOf(false) }
    var camera by remember { mutableStateOf<Camera?>(null) }
    val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { hasCamera = it }
    LaunchedEffect(Unit) { if (!hasCamera) permission.launch(Manifest.permission.CAMERA) }

    Column(Modifier.fillMaxSize().background(Color(0xFF17131D))) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null, tint = Color.White) }
            Text("وضع التتبّع", color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            IconButton(onClick = { flashOn = !flashOn; camera?.cameraControl?.enableTorch(flashOn) }) {
                Icon(if (flashOn) Icons.Default.FlashOn else Icons.Default.FlashOff, null, tint = Color.White)
            }
            IconButton(onClick = onPick) { Icon(Icons.Default.AddPhotoAlternate, null, tint = Color.White) }
        }
        Box(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 12.dp).clip(RoundedCornerShape(22.dp)).background(Color(0xFF30283A))) {
            if (hasCamera) {
                AndroidView(
                    modifier = Modifier.fillMaxSize(),
                    factory = { ctx ->
                        val previewView = PreviewView(ctx).apply {
                            layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
                            scaleType = PreviewView.ScaleType.FILL_CENTER
                        }
                        val providerFuture = ProcessCameraProvider.getInstance(ctx)
                        providerFuture.addListener({
                            try {
                                val provider = providerFuture.get()
                                val preview = Preview.Builder().build().also { it.surfaceProvider = previewView.surfaceProvider }
                                provider.unbindAll()
                                camera = provider.bindToLifecycle(lifecycleOwner, CameraSelector.DEFAULT_BACK_CAMERA, preview)
                            } catch (_: Exception) {}
                        }, ContextCompat.getMainExecutor(ctx))
                        previewView
                    }
                )
            } else {
                Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.CameraAlt, null, tint = Color.White, modifier = Modifier.size(50.dp))
                    Text("اسمح باستخدام الكاميرا لبدء التتبّع", color = Color.White)
                    Button(onClick = { permission.launch(Manifest.permission.CAMERA) }) { Text("السماح بالكاميرا") }
                }
            }
            if (imageUri != null) {
                var bitmap by remember(imageUri) { mutableStateOf<android.graphics.Bitmap?>(null) }
                LaunchedEffect(imageUri) {
                    bitmap = withContext(Dispatchers.IO) {
                        try { context.contentResolver.openInputStream(imageUri)?.use { BitmapFactory.decodeStream(it) } } catch (_: Exception) { null }
                    }
                }
                bitmap?.let {
                    Image(
                        bitmap = it.asImageBitmap(),
                        contentDescription = "الصورة المراد تتبّعها",
                        modifier = Modifier.fillMaxSize(),
                        alpha = opacity
                    )
                }
            } else {
                Text("اختر صورة من أعلى الشاشة لعرضها فوق الكاميرا", color = Color.White, modifier = Modifier.align(Alignment.BottomCenter).padding(16.dp), fontSize = 12.sp)
            }
        }
        Column(Modifier.fillMaxWidth().padding(horizontal = 22.dp, vertical = 14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("شفافية الصورة", color = Color.White, modifier = Modifier.weight(1f))
                Text("${(opacity * 100).toInt()}%", color = Color(0xFFD8C4F5), fontWeight = FontWeight.Bold)
            }
            Slider(value = opacity, onValueChange = onOpacity, valueRange = 0.1f..1f, colors = SliderDefaults.colors(thumbColor = Color(0xFFD2B5FF), activeTrackColor = Violet))
            Text("ثبّت الهاتف فوق الورقة، واضبط الشفافية ثم تتبّع الخطوط بالقلم.", color = Color(0xFFC7BDCF), fontSize = 12.sp)
            Spacer(Modifier.height(8.dp))
            Text("الحقوق © زهرتي", modifier = Modifier.align(Alignment.CenterHorizontally), color = Color(0xFF9A8EA8), fontSize = 11.sp)
        }
    }
}
